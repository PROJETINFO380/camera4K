package com.wpointgrey.client;

import java.nio.file.Paths;
import java.util.Scanner ;

import com.wpointgrey.jni.WPointGreyApp;

public class ClientJavaPointGray 
{

  static{
     System.loadLibrary("wpointgrey");
  }

   public static void main (String [] args )
   {
      
        WPointGreyApp api  = new WPointGreyApp();
		//initialisation du context de la et detection possible pre. caméra branché.
		api.initContext();
		
		System.out.println("bienvenue dans le gestionnaire(demo) interactif de capture d'image ");
		System.out.println("commandes acceptés : connect : se cnnecte a la camera \n   disconnect: se deconnecte de la camera \n info : afficher les informations  de la camera\n start : demarre la capture \n  stop : stop la capture ");
		
		
		Scanner clavier = new Scanner(System.in);

		
		String cmd = null;
		while ( (cmd = clavier.nextLine() )!="quit"){
		
			switch(cmd)			   {
				
				 case "connect":
					   api.connect();
						  break ;
				 case "disconnect" :
					   api.disconnect();
					break ;
				 case "info" :
						api.printCamera();
				 case "start":
						api.startCapture();
						break ;
				 case "stop" :
					 api.stopCapture();		 
				 break;
				 default :
				   System.out.println("commande nom prise en charge / inconnu !!");
			
			   }
			   
		    System.out.println("Entrer la commande : ");
			System.out.println("commandes acceptés : connect : se cnnecte a la camera \n   disconnect: se deconnecte de la camera \n info : afficher les informations  de la camera\n start : demarre la capture \n  stop : stop la capture ");
		
		}
	   api.destroysContext(); // destruction du context de la camera
	
   }
}
